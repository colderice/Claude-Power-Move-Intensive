# AI Profit Lab: Claude Starter Kit Quickstart Guide

**"Complexity is the enemy of execution."**

Welcome to the **Claude Starter Kit**. You have 501 skills available in the full bundle, but you are starting here because you want results *now*. I've hand-picked these 25 skills to help you build, market, and sell with AI in record time.

---

## Your First 3 Moves

If you don't know where to start, do this:

1.  **Deploy `Ai-Use-Case-Finder`:** Tell it about your business. It will show you exactly which other skills in this kit will provide the biggest ROI for your specific situation.
2.  **Define your `Customer-Persona`:** Every piece of copy you write with AI depends on this. Do this once, and everything else gets 10x better.
3.  **Build your `Lead-Magnet`:** Stop letting traffic bounce. Give people a reason to join your list so you can sell to them forever.

---

## How to use this Kit with Claude

### 1. The "Project" Method (Recommended)
If you have Claude Pro, create a **Project** named "Starter Kit".
- Upload the `SKILLS-DIRECTORY.md` (for indexing).
- Upload the specific skill folders you need for your current task.
- Upload any background info about your business (website copy, P&L, previous ads).

### 2. The "Active Instruction" Rule
Every skill in this kit is an "Active Instruction." When you paste a skill into Claude:
- **Phase 1 (Diagnosis):** Claude will interview you. Don't be vague. Be specific.
- **Phase 2 (Strategy):** Claude will propose a high-level approach. Critical: Review it. If it feels generic, push back.
- **Phase 3 (Execution):** Claude will deliver the final asset (copy, script, SOP, or spreadsheet).

---

## The Golden Rule of Profit
AI is great at generating *content*, but only humans can generate *trust*. Use these skills to handle the heavy lifting of drafting and research, so you can spend your time building relationships and closing deals.

**People + AI = Power®**

---

**Next Step:** Open [STARTER-KIT-DIRECTORY.md](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/STARTER-KIT-DIRECTORY.md) and pick your first skill.

Let's go.
