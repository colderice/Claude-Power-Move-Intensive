# AI Profit Lab: Claude Starter Kit Directory

**25 Essential Skills for Rapid Growth**

This curated kit contains the absolute essentials from the AI Profit Lab Ultimate Skills Bundle. These 25 skills are designed to take a small business owner from "zero" to "profitable agentic workflow" as quickly as possible.

## 1. Strategy & AI Foundations
| Skill | Description |
| :--- | :--- |
| **[Ai-Use-Case-Finder](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20ai-use-case-finder)** | Identifies AI automation opportunities in business workflows with ROI estimates. |
| **[Value-Proposition-Canvas](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20value-proposition-canvas)** | Maps your product's value to specific customer pains and gains. |
| **[Customer-Persona](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20customer-persona)** | Creates detailed psychographic profiles of your ideal buyers. |

## 2. Content & Growth (Driving Traffic)
| Skill | Description |
| :--- | :--- |
| **[Hook-Generator](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20hook-generator)** | Generates attention-grabbing opening lines for any content format. |
| **[Video-Script](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20video-script)** | Writes ready-to-film scripts for YouTube, TikTok, and Reels. |
| **[Content-Calendar](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20content-calendar)** | Generates a 30-day posting schedule mapped to business goals. |
| **[Linkedin-Profile-Optimizer](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20linkedin-profile-optimizer)** | Turns your LinkedIn profile into a landing page for your expertise. |
| **[Lead-Magnet](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20lead-magnet)** | Creates high-value opt-in gifts to build your email list. |

## 3. Sales & Revenue (Closing Deals)
| Skill | Description |
| :--- | :--- |
| **[Landing-Page-Copy](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20landing-page-copy)** | Writes high-converting copy for lead generation pages. |
| **[Sales-Page](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20sales-page)** | Writes long-form sales pages using the PAS (Problem-Agitate-Solution) framework. |
| **[Discovery-Call-Script](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20discovery-call-script)** | Qualifying questions and frameworks for the first sales conversation. |
| **[Sales-Script](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20sales-script)** | A repeatable conversation framework for closing the deal. |
| **[Objection-Handler](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20objection-handler)** | Response playbooks for price, timing, and trust concerns. |
| **[Product-Launch-Email](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20product-launch-email)** | The "Big Announcement" email sequence for new offers. |
| **[Welcome-Sequence](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20welcome-sequence)** | Automates the critical first impressions after a signup or sale. |

## 4. Operations & Systems (Scaling Up)
| Skill | Description |
| :--- | :--- |
| **[Sop-Builder](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20sop-builder)** | Converts conversational interviews into structured standard operating procedures. |
| **[Delegation-Framework](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20delegation-framework)** | Systems for handing off work to team members or VAs safely. |
| **[Job-Posting](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20job-posting)** | Writes ATS-friendly job ads that attract the right talent. |
| **[Product-Launch-Plan](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20product-launch-plan)** | The step-by-step roadmap for taking an idea to market. |
| **[Testimonial-Collector](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20testimonial-collector)** | Automates the collection of client proof and reviews. |
| **[Referral-Program](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20referral-program)** | Designs incentives that turn customers into a sales force. |

## 5. Security & Finance (The Foundation)
| Skill | Description |
| :--- | :--- |
| **[Pricing-Calculator](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20pricing-calculator)** | Builds margin-safe pricing models for products, services, and retainers. |
| **[Cash-Flow-Forecast](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20cash-flow-forecast)** | 3-12 month visibility into your business's bank balance. |
| **[Privacy-Policy](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20privacy-policy)** | GDPR and CCPA compliant legal documentation. |
| **[Contract-Writer](file:///Users/main/Desktop/Antigravity/The%20John%20Lawson%20AI%20Funnel%20%20/Claude%20Starter%20Kit/AIPL%20-%20contract-writer)** | Drafts professional service agreements and freelance contracts. |

---

**"Execute. Optimize. Profit."**
- John Lawson
